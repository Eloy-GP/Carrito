<?php

echo "INIT EXECUTION<br><br>";


include_once("com/cart/cart.php");
include_once("com/catalog/catalog.php");
include_once("com/users/users.php");

// AddProductToCatalog('250',20,0,'EU');

// DeleteProductQuantityFromCart('5', 17); 
CalculateCartTotal(); 
//AddToCart('20', 1);
//ExistProduct(10);

// RegisterUser('root3', 'pwd123');










?>